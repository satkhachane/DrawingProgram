﻿namespace DrawingProgram.Interfaces
{
    public interface ICommandParser
    {
        ICommand ParseCommand();
    }
}
