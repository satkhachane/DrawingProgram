﻿namespace DrawingProgram.Domains
{
    public class CanvasCommand : Command
    {
        public int Width { get; set; }
        public int Height { get; set; }
    }
}
